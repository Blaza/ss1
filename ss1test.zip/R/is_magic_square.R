is_magic_square <- function(mat) {

}
