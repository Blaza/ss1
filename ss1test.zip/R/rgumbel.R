rgumbel <- function(n) {

}
