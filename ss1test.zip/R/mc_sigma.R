mc_sigma <- function(n) {

}
