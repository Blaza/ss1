function_names <- c("exp_test", "is_magic_square", "mc_sigma", "rgumbel")

devtools::load_all(devtools::as.package(".")$path, quiet = TRUE)

filters <- sapply(function_names, function(name) {
  stripped_code <-
    gsub("\\{|\\}", "", paste(as.character(functionBody(name)), collapse = ""))
  if (stripped_code != "") {
    name
  } else {
    "NA"
  }
})

filters <- filters[filters != "NA"]

if (length(filters) == 0) {
  cat(testthat:::colourise("Nothing implemented. Skipping tests.", "skip"))
} else {

  filter_regex <- paste0("(", paste(filters, collapse = "|"), ")")

  cat(testthat:::colourise(sprintf("Testing: %s\n\n", filter_regex), "success"))

  devtools::test(filter=filter_regex)
}
