context("Magic square")

"process" <-
  function (x, n)
  {
    x <- x%%n
    x[x == 0] <- as.integer(n)
    return(x)
  }

"magic" <-
  function (n)
  {
    if(length(n)>1){
      return(sapply(n,match.fun(sys.call()[[1]])))
    }
    n <- round(n)
    if (n == 2) {
      stop("Normal magic squares of order 2 do not exist")
    }
    if (n%%2 == 1) {
      mat <- as.numeric(magic.2np1(floor(n/2)))
    }
    if (n%%4 == 0) {
      mat <- as.numeric(magic.4n(round(n/4)))
    }
    if (n%%4 == 2) {
      mat <- as.numeric(magic.4np2(round((n - 2)/4)))
    }

    matrix(mat, nrow=n)
  }

"magic.2np1" <-
  function (m, ord.vec = c(-1, 1), break.vec = c(1, 0), start.point = NULL)
  {
    if(length(m)>1){
      return(sapply(m,match.fun(sys.call()[[1]]),
                    ord.vec = ord.vec,
                    break.vec = break.vec,
                    start.point = start.point
      ))
    }
    n <- 2 * m + 1
    if (is.null(start.point)) {
      start.row <- 0
      start.col <- n + 1
    }
    else {
      start.row <- start.point[1] - 1
      start.col <- m + start.point[2] + 1
    }
    f <- function(n) {
      ord.row <- seq(from = start.row, by = ord.vec[1], length = n)
      ord.col <- seq(from = start.col, by = ord.vec[2], length = n)
      out <- cbind(rep(ord.row, n) - (n - 1), rep(ord.col,
                                                  n) + m)
      break.row <- ord.vec[1] - break.vec[1]
      break.col <- ord.vec[2] - break.vec[2]
      adjust <- cbind(rep(seq(from = 0, by = break.row, len = n),
                          each = n), rep(seq(from = 0, by = break.col, len = n),
                                         each = n))
      return(process(out - adjust, n))
    }
    a <- matrix(NA, n, n)
    a[f(n)] <- 1:(n * n)
    return(a)
  }

"magic.4n" <-
  function (m)
  {
    if(length(m)>1){
      return(sapply(m,match.fun(sys.call()[[1]])))
    }
    n <- 4 * m
    a <- matrix(1:(n^2), n, n)
    jj.1 <- kronecker(diag(2), matrix(1, 2, 2))
    jj <- as.logical(kronecker(matrix(1, m + 1, m + 1), jj.1)[2:(n +
                                                                   1), 2:(n + 1)])
    a[jj] <- rev(a[jj])
    return(a)
  }

"magic.4np2" <-
  function (m)
  {
    if(length(m)>1){
      return(sapply(m,match.fun(sys.call()[[1]])))
    }
    n <- 4 * m + 2
    f <- function(n) {
      if (n == 1) {
        return(matrix(c(4, 2, 1, 3), 2, 2))
      }
      if (n == 2) {
        return(matrix(c(1, 2, 4, 3), 2, 2))
      }
      if (n == 3) {
        return(matrix(c(1, 3, 4, 2), 2, 2))
      }
      return(NULL)
    }
    lux.n <- function(m) {
      lux <- matrix(1, 2 * m + 1, 2 * m + 1)
      lux[(m + 2), ] <- 2
      if (m > 1) {
        lux[(m + 3):(2 * m + 1), ] <- 3
      }
      lux[m + 1, m + 1] <- 2
      lux[m + 2, m + 1] <- 1
      return(lux)
    }
    i <- function(a, r) {
      jj <- which(a == r, arr.ind = TRUE)
      indices <- (cbind(jj[, 1] + (jj[, 3] - 1) * 2, jj[, 2] +
                          (jj[, 4] - 1) * 2))
      o <- order(indices[, 1] * nrow(jj) + indices[, 2])
      return(indices[o, ])
    }
    a <- apply(lux.n(m), 1:2, FUN = f)
    dim(a) <- c(2, 2, 2 * m + 1, 2 * m + 1)
    out <- matrix(NA, n, n)
    sequ <- as.vector(t(magic.2np1(m))) * 4 - 4
    out[i(a, 1)] <- sequ + 1
    out[i(a, 2)] <- sequ + 2
    out[i(a, 3)] <- sequ + 3
    out[i(a, 4)] <- sequ + 4
    return(out)
  }

test_that("Throws an error for non square matrix.", {
  expect_error(is_magic_square(1:3))
  expect_error(is_magic_square(matrix(1:8, nrow=2)))
})

test_that("Returns TRUE for valid magic square for n = 3.", {
  m <- magic(3)
  expect_equal(is_magic_square(m), TRUE)
})

test_that("Returns TRUE for valid magic square for n = 5.", {
  m <- magic(5)
  expect_equal(is_magic_square(m), TRUE)
})

test_that("Returns TRUE for valid magic square for n = 25.", {
  m <- magic(25)
  expect_equal(is_magic_square(m), TRUE)
})


test_that("Returns FALSE for random square matrix.", {
  m <- matrix(rnorm(9), nrow = 3)
  expect_equal(is_magic_square(m), FALSE)
})

test_that("Returns FALSE for non magic square (numbers not from 1:n^2, but all sums equal).", {
  m <- magic(5) + 1
  expect_equal(is_magic_square(m), FALSE)
})

test_that("Returns FALSE for non magic square (numbers not from 1:n^2, but all sums equal).", {
  m <- magic(25) + 1
  expect_equal(is_magic_square(m), FALSE)
})

test_that("Returns FALSE for non magic square (numbers not integer, but all sums equal).", {
  m <- magic(4)
  a <- matrix(c( 1, -1, -1,  1,
                 1, -1, -1,  1,
                -1,  1,  1, -1,
                -1,  1,  1, -1),
              byrow=TRUE, nrow=4) * 0.5
  n <- if (m[1,1] == 1) m + a else m - a
  expect_equal(is_magic_square(n), FALSE)
})

test_that("Returns FALSE for non magic square (not all sums equal, numbers from 1:n^2).", {
  m <- matrix(1:16, nrow = 4)
  expect_equal(is_magic_square(m), FALSE)
})
