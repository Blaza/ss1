context("Gumbel generator")

test_that("Throws an error for negative n.", {
  expect_error(rgumbel(-1))
})

test_that("Resulting length of the sample for n = 0 is zero.", {
  expect_equal(length(rgumbel(0)), 0)
})

test_that("Resulting length of the generated sample is correct.", {
  expect_equal(length(rgumbel(216)), 216)
})

test_that("The generated sample is from the correct distribution for n = 50.", {
  set.seed(1)
  expect_equal(ks.test(rgumbel(50), function(x) exp(-exp(-x)))$p.val > 0.05,
               TRUE)
})

test_that("The generated sample is from the correct distribution for n = 75.", {
  set.seed(1)
  expect_equal(ks.test(rgumbel(75), function(x) exp(-exp(-x)))$p.val > 0.05,
               TRUE)
})
