context("Exponential distribution test")

test_that("Throws an error for empty sample.", {
  expect_error(exp_test(numeric(0)))
})

test_that("Returns a logical value given a vector", {
  expect_equal(is.logical(exp_test(1:30)), TRUE)
})

test_that("Returns FALSE for exponential(3) sample of size 50", {
  expect_equal(exp_test(rexp(50, 3)), FALSE)
})

test_that("Returns TRUE for exponential(1) sample of size 50", {
  expect_equal(exp_test(rexp(50)), TRUE)
})

test_that("Returns FALSE for normal sample of size 50", {
  expect_equal(exp_test(rnorm(50)), FALSE)
})
