context("Monte Carlo sigma variance")

true_var <- function(n) {
  (1/n * (n - 1 - (2*gamma(n/2)^2)/(gamma((n-1)/2)^2))) * (n/(n-1))
}

test_that("Throws an error for negative n.", {
  expect_error(mc_sigma(-1))
})

test_that("Approximation is ok for n = 10.", {
  expect_equal(mc_sigma(10), true_var(10), tol = 0.01)
})

test_that("Approximation is ok for n = 20.", {
  expect_equal(mc_sigma(20), true_var(20), tol = 0.01)
})

test_that("Approximation is ok for n = 50.", {
  expect_equal(mc_sigma(50), true_var(50), tol = 0.01)
})

test_that("Approximation is ok for n = 100.", {
  expect_equal(mc_sigma(100), true_var(100), tol = 0.01)
})
